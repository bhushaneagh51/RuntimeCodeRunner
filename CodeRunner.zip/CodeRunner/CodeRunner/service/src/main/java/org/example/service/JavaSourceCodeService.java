package org.example.service;

import org.example.JavaSourceCode;
import org.example.core.exception.CodeCompilerException;
import org.example.core.service.InMemoryCompilationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.lang.reflect.InvocationTargetException;


@Service
public class JavaSourceCodeService {

    @Autowired
    InMemoryCompilationService inMemoryCompilationService;

    public JavaSourceCode compileCode(JavaSourceCode javaSourceCode) {
        try {
            inMemoryCompilationService.compileCode(javaSourceCode.getQualifiedClassName(), javaSourceCode.getSourceCode());
        } catch (CodeCompilerException e) {
            throw new RuntimeException(e);
        }
        return javaSourceCode;
    }

    public Object runCode(Object input, String qualifiedClassName) {
        try {
            return inMemoryCompilationService.run(qualifiedClassName, input);
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        } catch (InstantiationException e) {
            throw new RuntimeException(e);
        } catch (IllegalAccessException e) {
            throw new RuntimeException(e);
        } catch (NoSuchMethodException e) {
            throw new RuntimeException(e);
        } catch (InvocationTargetException e) {
            throw new RuntimeException(e);
        }
    }
}
