package org.example;

import org.example.core.service.InMemoryCompilationService;
import org.springframework.beans.factory.annotation.Configurable;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class ApplicationConfiguration {

    @Bean
    public InMemoryCompilationService inMemoryCompilationService() {
        return new InMemoryCompilationService();
    }
}
