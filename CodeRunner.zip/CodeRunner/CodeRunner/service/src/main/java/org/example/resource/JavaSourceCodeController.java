package org.example.resource;

import org.example.JavaSourceCode;
import org.example.service.JavaSourceCodeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class JavaSourceCodeController {

    @Autowired
    private JavaSourceCodeService javaSourceCodeService;

    @PostMapping("/compile")
    public ResponseEntity<JavaSourceCode> compileCode(@RequestBody JavaSourceCode javaSourceCode) {
        JavaSourceCode sourceCode = javaSourceCodeService.compileCode(javaSourceCode);
        return new ResponseEntity<>(sourceCode, HttpStatus.OK);
    }

    @PostMapping("/run/{qualifiedClassName}")
    public ResponseEntity<Object> runCode(@RequestBody Object input, @PathVariable("qualifiedClassName") String qualifiedClassName) {
        Object output = javaSourceCodeService.runCode(input, qualifiedClassName);
        return new ResponseEntity<>(output, HttpStatus.OK);
    }

}
