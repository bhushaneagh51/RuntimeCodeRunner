package org.example;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class JavaSourceCode {

    private String qualifiedClassName;

    private String sourceCode;

}
