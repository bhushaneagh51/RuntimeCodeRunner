rootProject.name = "CodeRunner"
include("core")
include("service")
