package org.example.core.inmemorycompilation;

public interface CustomFunction {

    default Object execute(Object input) {
        throw new IllegalArgumentException("Implementation not found");
    }
}