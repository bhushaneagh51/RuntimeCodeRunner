package org.example;

import org.example.core.inmemorycompilation.CustomFunction;
import org.example.core.inmemorycompilation.InMemoryFileManager;
import org.example.core.inmemorycompilation.JavaSourceFromString;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.tools.DiagnosticCollector;
import javax.tools.JavaCompiler;
import javax.tools.JavaFileObject;
import javax.tools.ToolProvider;
import java.util.Collections;
import java.util.List;

public class Main {

    public static final Logger LOGGER = LoggerFactory.getLogger(Main.class);

    public static void main(String[] args) throws ClassNotFoundException, InstantiationException, IllegalAccessException {

        String qualifiedClassName = "org.example.core.inmemorycompilation.TestClass";

        String sourceCode = "package org.example.core.inmemorycompilation;\n"
                + "public class TestClass implements CustomFunction {\n"
                + "@Override\n"
                + "    public Object execute(Object name) {\n"
                + "        System.out.println(\"code is running...\");\n"
                + "        return name;\n"
                + "    }\n"
                + "}\n";
        JavaCompiler compiler = ToolProvider.getSystemJavaCompiler();
        DiagnosticCollector<JavaFileObject> diagnostics = new DiagnosticCollector<>();
        InMemoryFileManager manager = new InMemoryFileManager(compiler.getStandardFileManager(null, null, null));

        List<JavaFileObject> sourceFiles = Collections.singletonList(new JavaSourceFromString(qualifiedClassName, sourceCode));

        JavaCompiler.CompilationTask task = compiler.getTask(null, manager, diagnostics, null, null, sourceFiles);

        boolean result = task.call();

        if (!result) {
            diagnostics.getDiagnostics()
                    .forEach(d -> LOGGER.error(String.valueOf(d)));
        } else {
            ClassLoader classLoader = manager.getClassLoader(null);
            Class<?> clazz = classLoader.loadClass(qualifiedClassName);
            CustomFunction instanceOfClass = (CustomFunction) clazz.newInstance();
            instanceOfClass.execute("hello");
        }
    }
}