package org.example.core.exception;

public class CodeCompilerException extends Exception {
    public CodeCompilerException() {
    }

    public CodeCompilerException(String message) {
        super(message);
    }

    public CodeCompilerException(String message, Throwable cause) {
        super(message, cause);
    }

    public CodeCompilerException(Throwable cause) {
        super(cause);
    }

    public CodeCompilerException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }
}
