package org.example.core.service;

import org.example.core.exception.CodeCompilerException;
import org.example.core.inmemorycompilation.CustomFunction;
import org.example.core.inmemorycompilation.InMemoryFileManager;
import org.example.core.inmemorycompilation.JavaSourceFromString;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.tools.DiagnosticCollector;
import javax.tools.JavaCompiler;
import javax.tools.JavaFileObject;
import javax.tools.ToolProvider;
import java.lang.reflect.InvocationTargetException;
import java.util.Collections;
import java.util.List;

public class InMemoryCompilationService {

    private JavaCompiler compiler;
    private DiagnosticCollector<JavaFileObject> diagnostics;
    private InMemoryFileManager manager;

    private static final Logger LOGGER = LoggerFactory.getLogger(InMemoryCompilationService.class);

    public InMemoryCompilationService() {
        this.compiler = ToolProvider.getSystemJavaCompiler();
        this.diagnostics = new DiagnosticCollector<>();
        this.manager = new InMemoryFileManager(compiler.getStandardFileManager(null, null, null));
    }

    public void compileCode(String qualifiedClassName, String sourceCode) throws CodeCompilerException {
        List<JavaFileObject> sourceFiles = Collections.singletonList(new JavaSourceFromString(qualifiedClassName, sourceCode));
        JavaCompiler.CompilationTask task = compiler.getTask(null, manager, diagnostics, null, null, sourceFiles);
        boolean result = task.call();
        if (!result) {
            diagnostics.getDiagnostics()
                    .forEach(d -> LOGGER.error(String.valueOf(d)));
            throw new CodeCompilerException("Failed to compile code");
        }
    }

    public Object run(String qualifiedClassName, Object input) throws ClassNotFoundException, InstantiationException, IllegalAccessException, NoSuchMethodException, InvocationTargetException {
        ClassLoader classLoader = manager.getClassLoader(null);
        Class<?> clazz = classLoader.loadClass(qualifiedClassName);
        CustomFunction instanceOfClass = (CustomFunction) clazz.getDeclaredConstructor().newInstance();
        return instanceOfClass.execute(input);
    }

}
